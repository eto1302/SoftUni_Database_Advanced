﻿using System;

namespace P03_FootballBetting
{
    class StartUp
    {
        static void Main(string[] args)
        {
           
        }
    }
}
